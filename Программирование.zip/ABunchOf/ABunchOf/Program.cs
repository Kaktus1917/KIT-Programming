﻿using System;
using System.Collections.Generic;
using System.Linq; // Подключённая библеотека

namespace ABunchOf
{
    internal class Progra
    {
        static void Main(string[] args)
        {
            Random random = new Random();

            int n = Examination();

            int[] A = new int[n];
            
            Console.WriteLine("Множество A");
            for (int i = 0; i < n; i++) // создание множества
            {
                int NewRandNumber = random.Next(1, 200+1);

                if (A.Contains(NewRandNumber)) //Поиск одинаковых элементов
                {
                    i--;
                    continue;
                }
                A[i] = NewRandNumber;
            }
            
            foreach (int i in A) // Вывод
                Console.Write(i + " ");
            Console.WriteLine("");

            n = Examination();
            int[] B = new int[n];
            for (int i = 0; i < n; i++) // создание множества
            {
                int RandNumber = random.Next(1, 200+1);

                if (B.Contains(RandNumber)) //Поиск одинаковых элементов
                {
                    i--;
                    continue;
                }
                B [i] = RandNumber;
            }
            Console.WriteLine("Множество B");
            foreach (int i in B) // Вывод
                Console.Write(i + " ");
            Console.WriteLine("");

            unionAandB(A, B);
            differenceAandB(A, B);
            symmetricalDifferenceAandB(A, B);

        }
        static void unionAandB(int[] a, int[] b)
        {

            int[] c = a.Union(b).ToArray(); // Обьеденение
            Console.WriteLine("Обьеденение множеств A и B");
            foreach (int i in c) // Вывод
                Console.Write(i + " ");
            Console.WriteLine("");
        }
        static void differenceAandB(int[] a, int[] b) // Разность
        {
            int[] c = a.Except(b).ToArray();
            Console.WriteLine("Разность множеств A и B");
            foreach (int i in c)
                Console.Write(i + " ");
            Console.WriteLine("");
        }
        static void symmetricalDifferenceAandB(int[] a, int[] b)
        {
            int[] c = a.Except(b).ToArray(); // Ищем разность
            int[] q = b.Except(a).ToArray(); // Ищем разность
            int[] Q = c.Union(q).ToArray(); // Объединяем
            Console.WriteLine("Симметрическая разность множеств A и B");
            foreach (int i in Q) // Вывод
                Console.Write(i + " ");
            Console.WriteLine("");
        }

        static int Examination() // проверка на формат данных
        {
            int n = 0;
            bool isRight = false;

            while (isRight == false)
            {
                try
                {
                    Console.WriteLine("Введите кол-во элементов множества");
                    n = Convert.ToInt32(Console.ReadLine());
                    isRight = true;
                }
                catch (FormatException)
                {
                    Console.WriteLine("Не верный формат");
                }
            }

            return n;
        }
    }
}
