﻿using System;

namespace recursion
{
    internal class Program
    {
        static int Factorial(int n)
        {
            if (n == 1) return 1;
            return n * Factorial(n - 1);
        }
        
        static int Fibonachi(int n)
        {
            if (n == 0 || n == 1) return n;
            return Fibonachi(n - 1) + Fibonachi(n - 2);
        }


        static void Main(string[] args)
        {
            int n,a;
            Console.WriteLine("Выберети: 1- факториал; 2- Фибоначчи");
            string b= Console.ReadLine();
            switch (b)
            {
                case "1":
                    Console.WriteLine("Введите число");
                    n = Convert.ToInt16(Console.ReadLine());
                    a = Factorial(n);
                    Console.WriteLine(a);
                    break;
                case "2":
                    Console.WriteLine("Введите номер числа Фибоначчи");
                    n = Convert.ToInt16(Console.ReadLine());
                    Console.WriteLine("Последовательность чисел");
                    for (int i = 1; i < n + 1; i++) 
                    { 
                        a = Fibonachi(i);
                        Console.Write(a+",");
                    }
                    break;
            }
            Console.ReadKey();
        }
    }
}
