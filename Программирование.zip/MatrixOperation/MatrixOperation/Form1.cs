﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace MatrixOperation
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        int[,] B, A, C, V1, V2; int n = 5;

        //Проверочные значения
        int AP, BP, V1P = 0, V2P = 0; string messageNumber;


        public static void Zapolnenie(int[,] matr, DataGridView dataGridView)
        {
            dataGridView.RowCount = matr.GetLength(0);
            dataGridView.ColumnCount = matr.GetLength(1);
            for (int i = 0; i < matr.GetLength(0); i++)
            {
                for (int j = 0; j < matr.GetLength(1); j++)
                {
                    dataGridView.Rows[i].Cells[j].Value = matr[i, j];
                }
            }

        }
        public static int [,] Reading (DataGridView dataGridView)
        {
            int[,] matrs = new int [dataGridView.RowCount, dataGridView.ColumnCount];
            
                for (int i = 0; i < dataGridView.RowCount; i++)
                {
                    for (int j = 0; j < dataGridView.ColumnCount; j++)
                    {
                        matrs[i, j] = Convert.ToInt32(dataGridView.Rows[i].Cells[j].Value);
                    }
                }
            return matrs;
        }


        private void ZapolnenieA_Click(object sender, EventArgs e)
        {
            n = 5;
            AP = 1;
            A = new int[n, n];
            Random random = new Random();
            int meaning;
            for (int i = 0; i < n; i++)
            {
                for (int j = 0; j < n; j++)
                {
                    meaning = random.Next(0, 100 + 1);
                    A[i, j] = meaning;
                }
            }
            Zapolnenie(A, dataGridViewA);
            TrackA.Text = ("След А");
            sidelineA.Text = ("Побоченая");
        }
        private void ZapolnenieB_Click(object sender, EventArgs e)
        {
            n = 5;
            BP =1;
            B = new int[n, n];
            Random random = new Random();
            int meaning;
            for (int i = 0; i < n; i++)
            {
                for (int j = 0; j < n; j++)
                {
                    meaning = random.Next(0, 100 + 1);
                    B[i, j] = meaning;
                }
            }
            Zapolnenie(B, dataGridViewB);
            TrackB.Text = ("След B");
            sidelineB.Text = ("Побоченая");
        }
        private void TrackA_Click(object sender, EventArgs e)
        {
            int j = 0, TrckA = 0;
            if (AP != 0)
            {
                for (int i = 0; i < n; i++)
                {
                    TrckA += A[i, j];
                    j++;
                }
                TrackA.Text = Convert.ToString(TrckA);
            }
            else
            {
                OutputMessageBox(messageNumber);
            }
           
            
        } // Проверка есть
        private void TrackB_Click(object sender, EventArgs e)
        {
            int j = 0, TrckB = 0;
            if (BP != 0)
            {
                for (int i = 0; i < n; i++)
                {
                    TrckB += B[i, j];
                    j++;
                }
                TrackB.Text = Convert.ToString(TrckB);
            }
            else
            {
                OutputMessageBox(messageNumber);
            }
        } // Проверка есть
        private void sidelineA_Click(object sender, EventArgs e)
        {
            int sideline = 0, j = 0;
            if (AP != 0)
            {
                for (int i = 4; i >= 0; i--)
                {
                    sideline += A[i, j];
                    j++;
                }
                sidelineA.Text = Convert.ToString(sideline);
            }
            else
            {
                OutputMessageBox(messageNumber);
            }
           
        } // Проверка есть
        private void sidelineB_Click(object sender, EventArgs e)
        {
            int sideline = 0, j = 0;
            if (BP != 0)
            {
                for (int i = 4; i >= 0; i--)
                {
                    sideline += B[i, j];
                    j++;
                }
                sidelineB.Text = Convert.ToString(sideline);
            }
            else
            {
                OutputMessageBox(messageNumber);
            }
           
        } // Проверка есть

        private void FillingVector1_Click(object sender, EventArgs e)
        {
            V1 = new int[n, 1];
            V1P = 1;
            Random random = new Random();
            int meaning;
            for (int i = 0; i < 5; i++)
            {
                for (int j = 0; j < 1; j++)
                {
                    meaning = random.Next(1, 10 + 1);
                    V1[i, j] = meaning;
                }
            }
            Zapolnenie(V1, dataGridViewVector1);
        }
        private void FillingVector2_Click(object sender, EventArgs e)
        {
            Random random = new Random();
            int meaning;
            V2P = 1;
            V2 = new int[n, 1];
              for (int i = 0; i < 5; i++)
              {
                 for (int j = 0; j < 1; j++)
                 {
                     meaning = random.Next(1, 10 + 1);
                     V2[i, j] = meaning;
                 }
                }
              Zapolnenie(V2, dataGridViewVector2);
            
        }

        private void aMultiplicationVector_Click(object sender, EventArgs e)
        {
            C = new int[n, 1];
            int Otv = 0;
            if (V1P != 0 & AP != 0)
            {
                for (int j = 0; j < n; j++)
                {
                    for (int i = 0; i < 5; i++)
                    {
                        Otv += A[i, j] * V1[j, 0];
                        C[i, 0] = Otv;
                    }
                }
                Zapolnenie(C, dataGridViewC);
            }
            else
            {
                OutputMessageBox(messageNumber);
            }
           
        } // Проверка есть
        private void bMultiplicationVector_Click(object sender, EventArgs e)
        {
            C = new int[n, 1];
            int Otv = 0;
            if (V2P != 0 & BP != 0)
            {
                for (int j = 0; j < n; j++)
                {
                    for (int i = 0; i < 5; i++)
                    {
                        Otv += B[i, j] * V1[j, 0];
                        C[i, 0] = Otv;
                    }
                }
                Zapolnenie(C, dataGridViewC);
            }
            else
            {
                OutputMessageBox(messageNumber);
            }
            
        } // Проверка есть

        private void AMultiplicationB_Click(object sender, EventArgs e)
        {
            if (BP != 0 & AP != 0)
            {
                C = new int[A.GetLength(0), B.GetLength(1)];
                for (int i = 0; i < A.GetLength(0); i++)
                {
                    for (int j = 0; j < B.GetLength(1); j++)
                    {
                        for (int k = 0; k < B.GetLength(0); k++)
                        {
                            C[i, j] += A[i, k] * B[k, j];
                        }
                    }
                }
                Zapolnenie(C, dataGridViewC);
            }
            else
            {
                OutputMessageBox(messageNumber);
            }
        } // Проверка есть

        private void matrixTranspositionA_Click(object sender, EventArgs e)
        {
            C = new int[n, n];
            if (AP != 0)
            {
                for (int i = 0; i < n; i++)
                {
                    for (int j = 0; j < n; j++)
                    {
                        C[i, j] = A[j, i];
                    }
                }
                Zapolnenie(C, dataGridViewC);
            }
            else
            {
                OutputMessageBox(messageNumber);
            }
            
        } // Проверка есть
        private void matrixTranspositionB_Click(object sender, EventArgs e)
        {
            C = new int[n, n];
            if (BP != 0)
            {
                for (int i = 0; i < n; i++)
                {
                    for (int j = 0; j < n; j++)
                    {
                        C[i, j] = B[j, i];
                    }
                }
                Zapolnenie(C, dataGridViewC);
            }
            else
            {
                OutputMessageBox(messageNumber);
            }
        } // Проверка есть

        private void Addition_Click(object sender, EventArgs e)
        {
            C = new int[n, n];
            if (AP != 0 & BP != 0)
            {
                for (int i = 0; i < n; i++)
                {
                    for (int j = 0; j < n; j++)
                    {
                        C[i, j] = A[i, j] + B[i, j];
                    }
                }
                Zapolnenie(C, dataGridViewC);
            }
            else 
            OutputMessageBox(messageNumber);
        } // Проверка есть
        private void Subtraction_Click(object sender, EventArgs e)
        {
            C = new int[n, n];
            if (AP != 0 & BP != 0)
            {
                for (int i = 0; i < n; i++)
                {
                    for (int j = 0; j < n; j++)
                    {
                        C[i, j] = A[i, j] - B[i, j];
                    }
                }
                Zapolnenie(C, dataGridViewC);
            }
            else 
            OutputMessageBox(messageNumber);
        } // Проверка есть

        private void OutputMessageBox(string messageNumber)
        {
          MessageBox.Show("Сначала создайте матрицу");
        }
    }
}