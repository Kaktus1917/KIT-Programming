﻿namespace MatrixOperation
{
    partial class Form1
    {
        /// <summary>
        /// Обязательная переменная конструктора.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Освободить все используемые ресурсы.
        /// </summary>
        /// <param name="disposing">истинно, если управляемый ресурс должен быть удален; иначе ложно.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Код, автоматически созданный конструктором форм Windows

        /// <summary>
        /// Требуемый метод для поддержки конструктора — не изменяйте 
        /// содержимое этого метода с помощью редактора кода.
        /// </summary>
        private void InitializeComponent()
        {
            this.backgroundWorker1 = new System.ComponentModel.BackgroundWorker();
            this.FillingA = new System.Windows.Forms.Button();
            this.FillingB = new System.Windows.Forms.Button();
            this.dataGridViewA = new System.Windows.Forms.DataGridView();
            this.dataGridViewB = new System.Windows.Forms.DataGridView();
            this.dataGridViewC = new System.Windows.Forms.DataGridView();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.AMultiplicationB = new System.Windows.Forms.Button();
            this.bMultiplicationVector = new System.Windows.Forms.Button();
            this.aMultiplicationVector = new System.Windows.Forms.Button();
            this.matrixTranspositionB = new System.Windows.Forms.Button();
            this.matrixTranspositionA = new System.Windows.Forms.Button();
            this.Subtraction = new System.Windows.Forms.Button();
            this.Addition = new System.Windows.Forms.Button();
            this.TrackA = new System.Windows.Forms.Button();
            this.TrackB = new System.Windows.Forms.Button();
            this.sidelineA = new System.Windows.Forms.Button();
            this.sidelineB = new System.Windows.Forms.Button();
            this.dataGridViewVector1 = new System.Windows.Forms.DataGridView();
            this.dataGridViewVector2 = new System.Windows.Forms.DataGridView();
            this.FillingVector1 = new System.Windows.Forms.Button();
            this.FillingVector2 = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewA)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewB)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewC)).BeginInit();
            this.groupBox1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewVector1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewVector2)).BeginInit();
            this.SuspendLayout();
            // 
            // FillingA
            // 
            this.FillingA.Location = new System.Drawing.Point(713, 12);
            this.FillingA.Name = "FillingA";
            this.FillingA.Size = new System.Drawing.Size(88, 23);
            this.FillingA.TabIndex = 3;
            this.FillingA.Text = "Заполнение A";
            this.FillingA.UseVisualStyleBackColor = true;
            this.FillingA.Click += new System.EventHandler(this.ZapolnenieA_Click);
            // 
            // FillingB
            // 
            this.FillingB.Location = new System.Drawing.Point(807, 12);
            this.FillingB.Name = "FillingB";
            this.FillingB.Size = new System.Drawing.Size(89, 23);
            this.FillingB.TabIndex = 4;
            this.FillingB.Text = "Заполнение B";
            this.FillingB.UseVisualStyleBackColor = true;
            this.FillingB.Click += new System.EventHandler(this.ZapolnenieB_Click);
            // 
            // dataGridViewA
            // 
            this.dataGridViewA.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridViewA.ColumnHeadersVisible = false;
            this.dataGridViewA.Dock = System.Windows.Forms.DockStyle.Left;
            this.dataGridViewA.Location = new System.Drawing.Point(0, 0);
            this.dataGridViewA.Name = "dataGridViewA";
            this.dataGridViewA.ReadOnly = true;
            this.dataGridViewA.RowHeadersVisible = false;
            this.dataGridViewA.Size = new System.Drawing.Size(212, 210);
            this.dataGridViewA.TabIndex = 5;
            // 
            // dataGridViewB
            // 
            this.dataGridViewB.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridViewB.ColumnHeadersVisible = false;
            this.dataGridViewB.Dock = System.Windows.Forms.DockStyle.Left;
            this.dataGridViewB.Location = new System.Drawing.Point(212, 0);
            this.dataGridViewB.Name = "dataGridViewB";
            this.dataGridViewB.ReadOnly = true;
            this.dataGridViewB.RowHeadersVisible = false;
            this.dataGridViewB.Size = new System.Drawing.Size(250, 210);
            this.dataGridViewB.TabIndex = 6;
            // 
            // dataGridViewC
            // 
            this.dataGridViewC.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridViewC.ColumnHeadersVisible = false;
            this.dataGridViewC.Dock = System.Windows.Forms.DockStyle.Left;
            this.dataGridViewC.Location = new System.Drawing.Point(462, 0);
            this.dataGridViewC.Name = "dataGridViewC";
            this.dataGridViewC.ReadOnly = true;
            this.dataGridViewC.RowHeadersVisible = false;
            this.dataGridViewC.Size = new System.Drawing.Size(245, 210);
            this.dataGridViewC.TabIndex = 7;
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.AMultiplicationB);
            this.groupBox1.Controls.Add(this.bMultiplicationVector);
            this.groupBox1.Controls.Add(this.aMultiplicationVector);
            this.groupBox1.Controls.Add(this.matrixTranspositionB);
            this.groupBox1.Controls.Add(this.matrixTranspositionA);
            this.groupBox1.Controls.Add(this.Subtraction);
            this.groupBox1.Controls.Add(this.Addition);
            this.groupBox1.Dock = System.Windows.Forms.DockStyle.Right;
            this.groupBox1.Location = new System.Drawing.Point(921, 0);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(180, 210);
            this.groupBox1.TabIndex = 8;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Действия";
            // 
            // AMultiplicationB
            // 
            this.AMultiplicationB.Location = new System.Drawing.Point(6, 135);
            this.AMultiplicationB.Name = "AMultiplicationB";
            this.AMultiplicationB.Size = new System.Drawing.Size(168, 22);
            this.AMultiplicationB.TabIndex = 6;
            this.AMultiplicationB.Text = "Умножение матриц";
            this.AMultiplicationB.UseVisualStyleBackColor = true;
            this.AMultiplicationB.Click += new System.EventHandler(this.AMultiplicationB_Click);
            // 
            // bMultiplicationVector
            // 
            this.bMultiplicationVector.Location = new System.Drawing.Point(87, 106);
            this.bMultiplicationVector.Name = "bMultiplicationVector";
            this.bMultiplicationVector.Size = new System.Drawing.Size(87, 23);
            this.bMultiplicationVector.TabIndex = 5;
            this.bMultiplicationVector.Text = "B * Вектор 2";
            this.bMultiplicationVector.UseVisualStyleBackColor = true;
            this.bMultiplicationVector.Click += new System.EventHandler(this.bMultiplicationVector_Click);
            // 
            // aMultiplicationVector
            // 
            this.aMultiplicationVector.Location = new System.Drawing.Point(6, 106);
            this.aMultiplicationVector.Name = "aMultiplicationVector";
            this.aMultiplicationVector.Size = new System.Drawing.Size(82, 23);
            this.aMultiplicationVector.TabIndex = 4;
            this.aMultiplicationVector.Text = "A * Вектор 1";
            this.aMultiplicationVector.UseVisualStyleBackColor = true;
            this.aMultiplicationVector.Click += new System.EventHandler(this.aMultiplicationVector_Click);
            // 
            // matrixTranspositionB
            // 
            this.matrixTranspositionB.Location = new System.Drawing.Point(6, 77);
            this.matrixTranspositionB.Name = "matrixTranspositionB";
            this.matrixTranspositionB.Size = new System.Drawing.Size(168, 23);
            this.matrixTranspositionB.TabIndex = 3;
            this.matrixTranspositionB.Text = "транспонирование B";
            this.matrixTranspositionB.UseVisualStyleBackColor = true;
            this.matrixTranspositionB.Click += new System.EventHandler(this.matrixTranspositionB_Click);
            // 
            // matrixTranspositionA
            // 
            this.matrixTranspositionA.Location = new System.Drawing.Point(6, 48);
            this.matrixTranspositionA.Name = "matrixTranspositionA";
            this.matrixTranspositionA.Size = new System.Drawing.Size(168, 23);
            this.matrixTranspositionA.TabIndex = 2;
            this.matrixTranspositionA.Text = "транспонирование A";
            this.matrixTranspositionA.UseVisualStyleBackColor = true;
            this.matrixTranspositionA.Click += new System.EventHandler(this.matrixTranspositionA_Click);
            // 
            // Subtraction
            // 
            this.Subtraction.Location = new System.Drawing.Point(87, 19);
            this.Subtraction.Name = "Subtraction";
            this.Subtraction.Size = new System.Drawing.Size(87, 23);
            this.Subtraction.TabIndex = 1;
            this.Subtraction.Text = "Вычитание";
            this.Subtraction.UseVisualStyleBackColor = true;
            this.Subtraction.Click += new System.EventHandler(this.Subtraction_Click);
            // 
            // Addition
            // 
            this.Addition.Location = new System.Drawing.Point(6, 19);
            this.Addition.Name = "Addition";
            this.Addition.Size = new System.Drawing.Size(82, 23);
            this.Addition.TabIndex = 0;
            this.Addition.Text = "Сложение";
            this.Addition.UseVisualStyleBackColor = true;
            this.Addition.Click += new System.EventHandler(this.Addition_Click);
            // 
            // TrackA
            // 
            this.TrackA.Location = new System.Drawing.Point(713, 41);
            this.TrackA.Name = "TrackA";
            this.TrackA.Size = new System.Drawing.Size(88, 23);
            this.TrackA.TabIndex = 2;
            this.TrackA.Text = "След А";
            this.TrackA.UseVisualStyleBackColor = true;
            this.TrackA.Click += new System.EventHandler(this.TrackA_Click);
            // 
            // TrackB
            // 
            this.TrackB.Location = new System.Drawing.Point(807, 41);
            this.TrackB.Name = "TrackB";
            this.TrackB.Size = new System.Drawing.Size(89, 23);
            this.TrackB.TabIndex = 3;
            this.TrackB.Text = "След B";
            this.TrackB.UseVisualStyleBackColor = true;
            this.TrackB.Click += new System.EventHandler(this.TrackB_Click);
            // 
            // sidelineA
            // 
            this.sidelineA.Location = new System.Drawing.Point(713, 70);
            this.sidelineA.Name = "sidelineA";
            this.sidelineA.Size = new System.Drawing.Size(88, 23);
            this.sidelineA.TabIndex = 11;
            this.sidelineA.Text = "Побоченая дтагональ ";
            this.sidelineA.UseVisualStyleBackColor = true;
            this.sidelineA.Click += new System.EventHandler(this.sidelineA_Click);
            // 
            // sidelineB
            // 
            this.sidelineB.Location = new System.Drawing.Point(807, 70);
            this.sidelineB.Name = "sidelineB";
            this.sidelineB.Size = new System.Drawing.Size(89, 23);
            this.sidelineB.TabIndex = 12;
            this.sidelineB.Text = "Побоченая";
            this.sidelineB.UseVisualStyleBackColor = true;
            this.sidelineB.Click += new System.EventHandler(this.sidelineB_Click);
            // 
            // dataGridViewVector1
            // 
            this.dataGridViewVector1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridViewVector1.ColumnHeadersVisible = false;
            this.dataGridViewVector1.Location = new System.Drawing.Point(713, 137);
            this.dataGridViewVector1.Name = "dataGridViewVector1";
            this.dataGridViewVector1.ReadOnly = true;
            this.dataGridViewVector1.RowHeadersVisible = false;
            this.dataGridViewVector1.Size = new System.Drawing.Size(88, 48);
            this.dataGridViewVector1.TabIndex = 13;
            // 
            // dataGridViewVector2
            // 
            this.dataGridViewVector2.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridViewVector2.ColumnHeadersVisible = false;
            this.dataGridViewVector2.EnableHeadersVisualStyles = false;
            this.dataGridViewVector2.Location = new System.Drawing.Point(807, 137);
            this.dataGridViewVector2.Name = "dataGridViewVector2";
            this.dataGridViewVector2.ReadOnly = true;
            this.dataGridViewVector2.RowHeadersVisible = false;
            this.dataGridViewVector2.Size = new System.Drawing.Size(89, 48);
            this.dataGridViewVector2.TabIndex = 14;
            // 
            // FillingVector1
            // 
            this.FillingVector1.Location = new System.Drawing.Point(713, 108);
            this.FillingVector1.Name = "FillingVector1";
            this.FillingVector1.Size = new System.Drawing.Size(88, 23);
            this.FillingVector1.TabIndex = 15;
            this.FillingVector1.Text = "Вектор 1";
            this.FillingVector1.UseVisualStyleBackColor = true;
            this.FillingVector1.Click += new System.EventHandler(this.FillingVector1_Click);
            // 
            // FillingVector2
            // 
            this.FillingVector2.Location = new System.Drawing.Point(807, 108);
            this.FillingVector2.Name = "FillingVector2";
            this.FillingVector2.Size = new System.Drawing.Size(88, 23);
            this.FillingVector2.TabIndex = 16;
            this.FillingVector2.Text = "Вектор 2";
            this.FillingVector2.UseVisualStyleBackColor = true;
            this.FillingVector2.Click += new System.EventHandler(this.FillingVector2_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1101, 210);
            this.Controls.Add(this.FillingVector2);
            this.Controls.Add(this.FillingVector1);
            this.Controls.Add(this.dataGridViewVector2);
            this.Controls.Add(this.dataGridViewVector1);
            this.Controls.Add(this.sidelineB);
            this.Controls.Add(this.sidelineA);
            this.Controls.Add(this.TrackB);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.TrackA);
            this.Controls.Add(this.dataGridViewC);
            this.Controls.Add(this.dataGridViewB);
            this.Controls.Add(this.dataGridViewA);
            this.Controls.Add(this.FillingB);
            this.Controls.Add(this.FillingA);
            this.Name = "Form1";
            this.Text = "Form1";
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewA)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewB)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewC)).EndInit();
            this.groupBox1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewVector1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewVector2)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion
        private System.ComponentModel.BackgroundWorker backgroundWorker1;
        private System.Windows.Forms.Button FillingA;
        private System.Windows.Forms.Button FillingB;
        private System.Windows.Forms.DataGridView dataGridViewA;
        private System.Windows.Forms.DataGridView dataGridViewB;
        private System.Windows.Forms.DataGridView dataGridViewC;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.Button Addition;
        private System.Windows.Forms.Button Subtraction;
        private System.Windows.Forms.Button TrackB;
        private System.Windows.Forms.Button TrackA;
        private System.Windows.Forms.Button sidelineA;
        private System.Windows.Forms.Button sidelineB;
        private System.Windows.Forms.Button matrixTranspositionA;
        private System.Windows.Forms.DataGridView dataGridViewVector1;
        private System.Windows.Forms.DataGridView dataGridViewVector2;
        private System.Windows.Forms.Button matrixTranspositionB;
        private System.Windows.Forms.Button FillingVector1;
        private System.Windows.Forms.Button FillingVector2;
        private System.Windows.Forms.Button bMultiplicationVector;
        private System.Windows.Forms.Button aMultiplicationVector;
        private System.Windows.Forms.Button AMultiplicationB;
    }
}

