﻿using System;

namespace BasicTableActions
{
    internal class Program
    {


        static void Main(string[] args)
        {
            int n, m, lineNumber, columnNumber;
            string choice;

            Console.WriteLine("Введите размер массива");
            Console.Write("Строки: ");
            n = Convert.ToInt32(Examination());
            Console.Write("Столбци: ");
            m = Convert.ToInt32(Examination());

            Random rnd = new Random();
            int[,] table = new int[n, m];
            for (int i = 0; i < n; i++)
            {
                for (int j = 0; j < m; j++)
                {
                    table[i, j] = rnd.Next(1000 + 1);
                    Console.Write(table[i, j] + "\t");
                }
                Console.WriteLine();
            }

            Console.WriteLine("Выберите один из пунктов:" + "\n" +
                "Сумма столбца - 1, Сумма строки - 2, Сумма массива - 3, Cумма в области - 4" + "\n" +
                "Среднее в столбце - 5, Среднее в строке - 6, Стреднее в массиве - 7, Среднее в области - 8" + "\n" +
                "Поиск в столбце - 9, Поиск в строке - 10, Поиски в массиве - 11, Поиск в области - 12" + "\n" +
                "Перестановка столбцов - 13, Перестановка строк - 14" + "\n" +
                "Сумма двух столбцов = 15, Сумма двух строк - 16" + "\n" +
                "Позиция мин в столбце - 17, Поцизия мин в строке - 18, Позиция мин в массиве - 19, Позиция мин в области - 20" + "\n" +
                "Позиция мах в столбце - 21, Поцизия мах в строке - 22, Позиция мах в массиве - 23, Позиция мах в области - 24" + "\n" + 
                "Выход - 0");

            choice = "-1";
            while (choice != "0")
            {
                Console.WriteLine("Выбирете пункт:");
                choice = Console.ReadLine();
                switch (choice)
                {
                    case "1":
                        Console.WriteLine("Введите номер столбца для вычесления суммы");
                        columnNumber = Convert.ToInt32(Examination());
                        Console.WriteLine("Сумма:" + sumColumn(n, columnNumber, table));
                        break;

                    case "2":
                        Console.WriteLine("Введите номер строки для вычесления суммы");
                        lineNumber = BorderExaminationLine(table, n);
                        Console.WriteLine("Сумма:" + sumLine(m, lineNumber, table));
                        break;

                    case "5":
                        Console.WriteLine("Введите номер столбца для вычесления средней");
                        columnNumber = BorderExaminationColumn(table, m);
                        Console.WriteLine("Средняя:" + aveColumn(n, columnNumber, table));
                        break;

                    case "6":
                        Console.WriteLine("Введите номер строки для вычесления средней");
                        lineNumber = BorderExaminationLine(table, n);
                        Console.WriteLine("Средняя:" + aveLine(m, lineNumber, table));
                        break;

                    case "3":
                        sumTable(n, m, table);
                        break;

                    case "7":
                        aveTable(n, m, table);
                        break;

                    case "4":

                        int downBorder = 0;
                        int topBorder = 0;
                        int leftBorder = 0;
                        int rightBorder = 0;
                        BorderExamination(table, ref leftBorder, ref rightBorder, ref downBorder, ref topBorder, n, m);
                        Console.WriteLine("Ответ(сумма в области):" + sumInTheArea(downBorder, topBorder, leftBorder, rightBorder, table));
                        break;

                    case "8":
                        downBorder = 0;
                        topBorder = 0;
                        leftBorder = 0;
                        rightBorder = 0;
                        BorderExamination(table, ref leftBorder, ref rightBorder, ref downBorder, ref topBorder, n, m);
                        Console.WriteLine("Ответ(средняя в области):" + aveInTheArea(downBorder, topBorder, leftBorder, rightBorder, table, n, m));
                        break;

                    case "16":
                        Console.WriteLine("Введите первую строку");
                        int lineNumber1 = Convert.ToInt32(Examination());
                        Console.WriteLine("Введите вторую строку");
                        int lineNumber2 = Convert.ToInt32(Examination());
                        Console.WriteLine(sumTwoLine(m, lineNumber1, lineNumber2, table));
                        break;

                    case "15":
                        Console.WriteLine("Введите первый столбец");
                        int ColumnNumber1 = BorderExaminationColumn(table, m);
                        Console.WriteLine("Введите второй столбец");
                        int ColumnNumber2 = BorderExaminationColumn(table, m);
                        Console.WriteLine(sumTwoColumn(n, ColumnNumber1, ColumnNumber2, table));
                        break;

                    case "11":
                        Console.WriteLine("Введите значение из массива");
                        int searchElement = Convert.ToInt32(Examination());
                        matrixSearch(searchElement, n, m, table);
                        break;

                    case "12":
                        Console.WriteLine("Введите значение из массива");
                        searchElement = Convert.ToInt32(Examination());
                        downBorder = 0;
                        topBorder = 0;
                        leftBorder = 0;
                        rightBorder = 0;
                        BorderExamination(table, ref leftBorder, ref rightBorder, ref downBorder, ref topBorder, n, m);
                        searchInTheArea(downBorder, topBorder, leftBorder, rightBorder, searchElement, table);
                        break;

                    case "9":
                        Console.WriteLine("Введите номер столбца для вычесления суммы");
                        columnNumber = BorderExaminationColumn(table, m);
                        Console.WriteLine("Введите значение из массива");
                        searchElement = Convert.ToInt32(Examination());
                        searchInColumn(n, columnNumber, searchElement, table);
                        break;

                    case "10":
                        Console.WriteLine("Введите номер строки для вычесления суммы");
                        lineNumber = BorderExaminationLine(table, n);
                        Console.WriteLine("Введите значение из массива");
                        searchElement = Convert.ToInt32(Examination());
                        searchInLine(m, lineNumber, searchElement, table);
                        break;

                    case "13":
                        Console.WriteLine("Введите номер столбца которую хотитье поменять");
                        ColumnNumber1 = BorderExaminationColumn(table, m);
                        Console.WriteLine("Введите вторую столбец");
                        ColumnNumber2 = BorderExaminationColumn(table, m);
                        switchColumn(n, m, ColumnNumber1, ColumnNumber2, ref table);
                        break;

                    case "14":
                        Console.WriteLine("Введите номер строки которую хотитье поменять");
                        ColumnNumber1 = BorderExaminationLine(table, n);
                        Console.WriteLine("Введите вторую строку");
                        ColumnNumber2 = BorderExaminationLine(table, n);
                        switchLine(n, m, ColumnNumber1, ColumnNumber2, ref table);
                        break;

                    case "19":
                        mininTheMatrix(n, m, table);
                        break;

                    case "20":
                        minInTheArea(n, m, table);
                        break;

                    case "17":
                        minInTheColumn(n, m, table);
                        break;

                    case "18":
                        minInTheLine(m, n, table);
                        break;

                    case "23":
                        maxInTheTable(n, m, table);
                        break;

                    case "24":
                        maxInTheArea(n, m, table);
                        break;

                    case "21":
                        maxInTheColumn(n, m, table);
                        break;

                    case "22":
                        maxInTheLine(m, n, table);
                        break;

                    default:
                        Console.WriteLine("Нет такого пункта");
                        break;
                }


            }
        }
           
        static int sumColumn(int n, int ColumnNumber, int[,] table)
        {
            int Sum = 0;
            for (int i = 0; i < n; i++)
            {
                Sum = Sum + table[i, ColumnNumber - 1];
            }
            return Sum;
        }
        static int sumLine(int m, int lineNumber, int[,] table)
        {
            int Sum = 0;
       
            for (int i = 0; i < m; i++)
            {
                Sum = Sum + table[lineNumber - 1, i];
            }
            return Sum;
        }
        static double aveColumn(int n, int ColumnNumber, int[,] table)
        {
            int ave = 0, Sum = 0; double average = 0;
            for (int i = 0; i < n; i++)
            {
                ave++;
                Sum = Sum + table[i, ColumnNumber - 1];
                average = Sum / ave;
            }
            return average;
        }
        static double aveLine(int m, int lineNumber, int[,] table)
        {
            int ave = 0, Sum = 0; double average = 0;
            for (int j = 0; j < m; j++)
            {
                ave++;
                Sum = Sum + table[lineNumber - 1, j];
                average = Sum / ave;
            }
            return average;
        }
        static void sumTable(int n, int m, int[,] table)
        {
            int Sum = 0;
            for (int i = 0; i < n; i++)
                for (int j = 0; j < m; j++)
                {
                    Sum = Sum + table[i, j];
                }
            Console.WriteLine("вычесления суммы всей таблицы = {0}", Sum);

        }
        static void aveTable(int n, int m, int[,] table)
        {
            int Sum = 0, ave = 0;
            for (int i = 0; i < n; i++)
                for (int j = 0; j < m; j++)
                {
                    ave++;
                    Sum = Sum + table[i, j];
                }

            double average = Sum / ave;
            Console.WriteLine("вычесления средней всей таблицы = {0}", average);
        }
        static int sumInTheArea(int Down, int Top, int Left, int Right, int[,] table)
        {
            int Sum = 0;
           
            for (int i = Top; i < Down; i++)
            {
                for (int j = Left - 1; j < Right; j++)
                {
                    Sum += table[i, j];
                }
            }
            return Sum;
        }
        static double aveInTheArea(int Down, int Top, int Left, int Right, int[,] table, int n, int m)
        {

            int Sum = 0, ave = 0;
            double average = 0;

            Down = 0; Top = 0; Left = 0; Right = 0;
            BorderExamination(table, ref Left, ref Right, ref Down, ref Top, n, m);

            for (int i = Top; i < Down; i++)
            {
                for (int j = Left - 1; j < Right; j++)
                {
                    Sum += table[i, j];
                    ave++;
                }
            }
            if (ave > 0)
            {
                average = Sum / ave;
            }

            return average;
        }
        static int sumTwoLine(int m, int lineNumber1, int lineNumber2, int[,] table)
        {
            int Sum = sumLine(m, lineNumber1, table) + sumLine(m, lineNumber2, table);
            return Sum;
        }
        static int sumTwoColumn(int n, int ColumnNumber1, int ColumnNumber2, int[,] table)
        {
            int Sum = sumColumn(n, ColumnNumber1, table) + sumColumn(n, ColumnNumber2, table);
            return Sum;
        }
        static void matrixSearch(int searchElement, int n, int m, int[,] table)
        {
            int M = 0, N = 0;
            for (int i = 0; i < n; i++)
                for (int j = 0; j < m; j++)
                    if (table[i, j] == searchElement)
                    {
                        N = i + 1;
                        M = j + 1;
                    }
            if (M == 0 || N == 0)
            {
                Console.WriteLine("Индекс числа = Нет такого числа в массиве");
            }
            else
            {
                Console.WriteLine("Индекс числа = [{0},{1}]", N, M);
            }

        }
        static void searchInTheArea(int Down, int Top, int Left, int Right, int searchElement, int[,] table)
        {
            int N = 0, M = 0;
            for (int i = Top; i < Down; i++)
            {
                for (int j = Left - 1; j < Right; j++)
                {
                    if (table[i, j] == searchElement)
                    {
                        N = i + 1;
                        M = j + 1;
                    }
                }
            }
            if (M == 0 || N == 0)
            {
                Console.WriteLine("Индекс числа = Нет такого числа в массиве");
            }
            else
            {
                Console.WriteLine("Индекс числа = [{0},{1}]", N, M);
            }
        }
        static void searchInColumn(int n, int ColumnNumber, int searchElement, int[,] table)
        {
            int M = 0, N = 0;
            for (int i = 0; i < n; i++)
            {
                if (table[i, ColumnNumber - 1] == searchElement)
                {
                    N = i + 1;
                    M = ColumnNumber + 2;
                }
                if (M == 0 || N == 0)
                {
                    Console.WriteLine("Индекс числа = Нет такого числа в массиве");
                }
                else
                {
                    Console.WriteLine("Индекс числа = [{0},{1}]", N, M);
                }
            }

        }
        static void searchInLine(int m, int LineNumber, int searchElement, int[,] table)
        {
            int M = 0, N = 0;
            for (int j = 0; j < m; j++)
            {
                if (table[LineNumber - 1, j] == searchElement)
                {
                    N = LineNumber + 2;
                    M = j + 1;
                }
                if (M == 0 || N == 0)
                {
                    Console.WriteLine("Индекс числа = Нет такого числа в массиве");
                }
                else
                {
                    Console.WriteLine("Индекс числа = [{0},{1}]", N, M);
                }
            }

        }
        static void switchColumn(int n, int m, int numberColumn1, int numberColumn2, ref int[,] table)
        {
            int switchcolumn;
            for (int i = 0; i < n; i++)
            {
                for (int j = 0; j < numberColumn1; j++)
                {
                    switchcolumn = table[i, numberColumn1 - 1];
                    table[i, numberColumn1 - 1] = table[i, numberColumn2 - 1];
                    table[i, numberColumn2 - 1] = switchcolumn;

                }
            }
            Console.WriteLine("Результат");
            for (int i = 0; i < n; i++)
            {
                for (int j = 0; j < m; j++)
                {
                    Console.Write(table[i, j] + "\t");
                }
                Console.WriteLine();
            }
        }
        static void switchLine(int n, int m, int numberLine1, int numberLine2, ref int[,] table)
        {
            int switchcolumn;
            for (int i = 0; i < numberLine1; i++)
            {
                for (int j = 0; j < m; j++)
                {
                    switchcolumn = table[numberLine1 - 1, j];
                    table[numberLine1 - 1, j] = table[numberLine2 - 1, j];
                    table[numberLine2 - 1, j] = switchcolumn;

                }
            }
            Console.WriteLine("Результат");
            for (int i = 0; i < n; i++)
            {
                for (int j = 0; j < m; j++)
                {
                    Console.Write(table[i, j] + "\t");
                }
                Console.WriteLine();
            }
        }
        static void mininTheMatrix(int n, int m, int[,] table)
        {
            int min = 100000000;
            for (int i = 0; i < n; i++)
                for (int j = 0; j < m; j++)
                    if (min > table[i, j])
                    {
                        min = table[i, j];
                    }
            
            Console.WriteLine("Минимальное значение в массиве:" + min);
            matrixSearch(min, n, m, table);
        }
        static void minInTheArea(int n, int m, int[,] table)
        {
            int downBorder = 0, topBorder = 0, leftBorder = 0, rightBorder = 0;
            BorderExamination(table, ref leftBorder, ref rightBorder, ref downBorder, ref topBorder, n, m);
            int min = 100000000;
            for (int i = topBorder; i < downBorder; i++)
            {
                for (int j = leftBorder - 1; j < rightBorder; j++)
                {
                    if (min > table[i, j])
                    {
                        min = table[i, j];
                    }
                }
            }
            Console.WriteLine("Минимальное значение в массиве:" + min);
            searchInTheArea(downBorder, topBorder, leftBorder, rightBorder, min, table);
        }
        static void minInTheColumn(int n, int ColumnNumber, int[,] table)
        {
            Console.WriteLine("Введите номер стобца");
            ColumnNumber = BorderExaminationColumn(table, n);
            int M = 0, N = 0, min = 1000000;
            for (int i = 0; i < n; i++)
            {
                if (min > table[i, ColumnNumber - 1])
                {
                    min = table[i, ColumnNumber - 1];
                }
            }
            Console.WriteLine("Минимальное значение в массиве:" + min);
            searchInColumn(n, ColumnNumber, min, table);
        }
        static void minInTheLine(int m, int lineNumber, int[,] table)
        {
            Console.WriteLine("Введите номер строки");
            lineNumber = BorderExaminationLine(table, m);
            int M = 0, N = 0, min = 1000000;
            for (int j = 0; j < m; j++)
            {
                if (min > table[lineNumber - 1, j])
                {
                    min = table[lineNumber - 1, j];
                }
            }
            Console.WriteLine("Минимальное значение в массиве:" + min);
            searchInLine(m, lineNumber, min, table);
        }
        static void maxInTheTable(int n, int m, int[,] table)
        {
            int max = 0;
            for (int i = 0; i < n; i++)
                for (int j = 0; j < m; j++)
                    if (max < table[i, j])
                    {
                        max = table[i, j];
                    }
            Console.WriteLine("Минимальное значение в массиве:" + max);
            matrixSearch(max, n, m, table);
        }
        static void maxInTheArea(int n, int m, int[,] table)
        {
            int downBorder = 0, topBorder = 0, leftBorder = 0, rightBorder = 0;
            BorderExamination(table, ref leftBorder, ref rightBorder, ref downBorder, ref topBorder, n, m);
            int max = 0;
            for (int i = topBorder; i < downBorder; i++)
            {
                for (int j = leftBorder - 1; j < rightBorder; j++)
                {
                    if (max < table[i, j])
                    {
                        max = table[i, j];
                    }
                }
            }
            Console.WriteLine("Минимальное значение в массиве:" + max);
            searchInTheArea(downBorder, topBorder, leftBorder, rightBorder, max, table);
        }
        static void maxInTheColumn(int n, int ColumnNumber, int[,] table)
        {
            Console.WriteLine("Введите номер стобца");
            ColumnNumber = BorderExaminationColumn(table, n);
            int M = 0, N = 0, max = 0;
            for (int i = 0; i < n; i++)
            {
                if (max < table[i, ColumnNumber - 1])
                {
                    max = table[i, ColumnNumber - 1];
                }
            }
            Console.WriteLine("Минимальное значение в массиве:" + max);
            searchInColumn(n, ColumnNumber, max, table);
        }
        static void maxInTheLine(int m, int lineNumber, int[,] table)
        {
            Console.WriteLine("Введите номер строки");
            lineNumber = BorderExaminationLine(table, m);
            int M = 0, N = 0, max = 0;
            for (int j = 0; j < m; j++)
            {
                if (max < table[lineNumber - 1, j])
                {
                    max = table[lineNumber - 1, j];
                }
            }
            Console.WriteLine("Минимальное значение в массиве:" + max);
            searchInLine(m, lineNumber, max, table);
        }

        static int Examination()
        {
            int n = 0;
            bool isRight = false;
            while (isRight == false)
            {
                try
                {
                    n = Convert.ToInt32(Console.ReadLine());

                    isRight = true;
                }
                catch (Exception)
                {
                    Console.WriteLine("Неверный формат");
                }
            }
            return n;
        }

        static void BorderExamination(int[,] table, ref int leftBorder, ref int rightBorder, ref int bottomBorder, ref int topBorder, int n, int m)
        {
            bool isRight = false;
           
            while(isRight == false)
            {
                Console.WriteLine("Введите низ области");
                bottomBorder = Convert.ToInt32(Examination());
                Console.WriteLine("Введите верх области");
                topBorder = Convert.ToInt32(Examination());
                Console.WriteLine("Введите лево области");
                leftBorder = Convert.ToInt32(Examination());
                Console.WriteLine("Введите право области");
                rightBorder = Convert.ToInt32(Examination());
                if (bottomBorder > topBorder && leftBorder < rightBorder && leftBorder > 0 && rightBorder < m && bottomBorder < n && topBorder > 0)
                {
                    isRight = true;
                }
                else
                {
                    Console.WriteLine("Неверные границы области: лево должно быть меньше права, а верх меньше низа");
                }
            }
        }

        static int BorderExaminationColumn(int[,] table, int m)
        {
            int num = 0;
            bool isRight = false;
            
            while(isRight == false)
            {
                num = Convert.ToInt32(Examination());
                if(num < m && num > 0)
                {
                    isRight = true;
                }
                else
                {
                    Console.WriteLine("Номер колонки должен быть меньше");
                }
            }
            return num;
        }

        static int BorderExaminationLine(int[,] table, int n)
        {
            int num = 0;
            bool isRight = false;

            while (isRight == false)
            {
                num = Convert.ToInt32(Examination());
                if (num < n && num > 0)
                {
                    isRight = true;
                }
                else
                {
                    Console.WriteLine("Номер строик должен быть меньше");
                }
            }
            return num;
        }

    }
}