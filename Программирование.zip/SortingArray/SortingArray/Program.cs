﻿using System;
using System.Diagnostics;

namespace SortingArray
       
{
    class Program
    {
        static void Main(string[] args)
        {
            int Left = 0, Right = 0;
            int[] A = new int[20];
            bool isRight = false;

            while(isRight == false)
            {
                try
                {
                    Console.Write("Введите левую границу: ");
                    Left = Convert.ToInt32(Console.ReadLine());
                    Console.Write("Введите правую границу: ");
                    Right = Convert.ToInt32(Console.ReadLine());
                    isRight = true;
                }
                catch(FormatException)
                {
                    Console.WriteLine("Ошибка");
                    Console.Clear();
                }
            }
            

            Random rnd = new Random();

            for (int i = 0; i < 20; i++)
            {
                int r = rnd.Next(Left, Right + 1);
                A[i] = r;
            }
            Console.WriteLine("Массив A");
            foreach (int i in A)
                Console.Write(i + " ");
            Console.WriteLine("");

            Console.WriteLine("Массив сортированый с помощью пузырки:");
             int[] aSortingBubble= bubble(A);
            foreach (int i in aSortingBubble)
                Console.Write(i + " ");
            Console.WriteLine("");


            int[] aSortedArray = QuickSort(A, 0, A.Length - 1);

            Console.WriteLine("Отсартированный массив с помощью <<Быстрой сортировки>>:");
            Console.WriteLine(string.Join(" ", aSortedArray));

            Stopwatch time = new Stopwatch();

            int[] B = new int[5000];
            for (int i = 0; i < 5000; i++)
            {
                int r = rnd.Next(1, 1000 + 1);
                B[i] = r;
            }

            //time.Start();
            //int[] bSortingBubble = bubble(B);
            //time.Stop();
            //Console.WriteLine(time.ElapsedMilliseconds); time.Reset();

            //time.Start();
            //int[] bSortedArray = QuickSort(B, 0, B.Length - 1);
            //time.Stop();
            //Console.WriteLine(time.ElapsedMilliseconds);






            Console.ReadLine();
        }
        static int[] bubble ( int[] A)
        {
            int temp;
            for (int i = 0; i < A.Length; i++)
            {
                for (int j = i + 1; j < A.Length; j++)
                {
                    if (A[i] > A[j])
                    {
                        temp = A[i];
                        A[i] = A[j];
                        A[j] = temp;
                    }
                }
            }
            return A;
        }
        private static int[] QuickSort(int[] array, int minIndex, int maxIndex)
        {
            if (minIndex >= maxIndex)
            {
                return array;
            }

            int pivotIndex = GetPivotIndex(array, minIndex, maxIndex);

            QuickSort(array, minIndex, pivotIndex - 1);

            QuickSort(array, pivotIndex + 1, maxIndex);

            return array;
        }

        private static int GetPivotIndex(int[] array, int minIndex, int maxIndex)
        {
            int pivot = minIndex - 1;

            for (int i = minIndex; i <= maxIndex; i++)
            {
                if (array[i] < array[maxIndex])
                {
                    pivot++;
                    Swap(ref array[pivot], ref array[i]);
                }
            }

            pivot++;
            Swap(ref array[pivot], ref array[maxIndex]);

            return pivot;
        }

        private static void Swap(ref int leftItem, ref int rightItem)
        {
            int temp = leftItem;

            leftItem = rightItem;

            rightItem = temp;
        }
    }
}
